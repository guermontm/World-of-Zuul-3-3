import java.awt.*;
import java.io.*;
import java.util.*;

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class ContainerTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class ContainerTest
{
    private Container containerTest;
    private SimpleObject key,computer; 
    private ArrayList<SimpleObject> testList;
    /**
     * Default constructor for test class ContainerTest
     */
    public ContainerTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
        containerTest = new Container("couch", false);
        key = new SimpleObject("key",true);
        computer = new SimpleObject("computer",false);
        containerTest.listContent.add(key);
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

    /**
     * Method testAddObject test that an object is added to the list
     *
     */
    @Test
    public void testAddObject()
    {
        containerTest.addObject(computer);
        assertEquals(2, containerTest.getListContentObject().size());
    } 

    /**
     * Method testRemoveObject test that an object is remove from the list 
     *
     */
    @Test
    public void testRemoveObject()
    {
        containerTest.removeObject("key");
        assertEquals(0, containerTest.getListContentObject().size());
    } 

    /**
     * Method testGetListContentObject test that the list is good 
     *
     */
    @Test
    public void testGetListContentObject()
    {
        assertEquals(1, containerTest.getListContentObject().size());
    } 

    /**
     * Method testInteractItem test the System.out.println in the interactItem method. 
     *
     */
    @Test
    public void testInteractItem() throws Exception 
    {
        containerTest.removeObject("key");

        PrintStream save_out=System.out;
        final ByteArrayOutputStream out = new ByteArrayOutputStream();
        System.setOut(new PrintStream(out));

        containerTest.interactItem();

        assertEquals("The couch does not contain anything\r\n", out.toString());
    } 
    
    /**
     * Method testGetName test if the name is not empty 
     *
     */
    @Test
    public void testGetName()
    {
        if(containerTest.getName()=="")
        {
            fail("The name cannot be null");
        }
        else 
        {
         assertEquals("couch", containerTest.getName());   
        }
    }
    
    /**
     * Method testGetLock test if the boolean lock is the same as the initialization 
     *
     */
    @Test
    public void testGetLock()
    {
        assertEquals(false, containerTest.getLock());
    }
    
    
    /**
     * Method testSetLock test the method which change isLock 
     *
     */
    @Test
    public void testSetLock()
    {
        containerTest.setLock();
        assertEquals(true, containerTest.getLock());
    }
}
