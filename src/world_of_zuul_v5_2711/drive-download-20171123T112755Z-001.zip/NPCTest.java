import java.awt.*;
import java.io.*;
import java.util.*;
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class NPCTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class NPCTest
{
    private NPC nonPlayerC;

    /**
     * Default constructor for test class NPCTest
     */
    public NPCTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
        nonPlayerC = new NPC("Steve",false);
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

    /**
     * Method testInteractItem test the System.out.println in the interactItem method. 
     *
     */
    @Test
    public void testInteractItem() throws Exception {
        PrintStream save_out=System.out;
        final ByteArrayOutputStream out = new ByteArrayOutputStream();
        System.setOut(new PrintStream(out));

        nonPlayerC.interactItem();

        //String expectedOutput  = "Hello";
        assertEquals("Hello\r\n", out.toString());
    } 
    
        /**
     * Method testGetName test if the name is not empty 
     *
     */
    @Test
    public void testGetName()
    {
        if(nonPlayerC.getName()=="")
        {
            fail("The name cannot be null");
        }
        else 
        {
         assertEquals("Steve", nonPlayerC.getName());   
        }
    }
    
    /**
     * Method testGetLock test if the boolean lock is the same as the initialization 
     *
     */
    @Test
    public void testGetLock()
    {
        assertEquals(false, nonPlayerC.getLock());
    }
    
    
    /**
     * Method testSetLock test the method which change isLock 
     *
     */
    @Test
    public void testSetLock()
    {
        nonPlayerC.setLock();
        assertEquals(true, nonPlayerC.getLock());
    }
}
