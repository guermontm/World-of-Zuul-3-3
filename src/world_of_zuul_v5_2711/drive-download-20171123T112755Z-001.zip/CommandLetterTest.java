

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class CommandLetterTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class CommandLetterTest
{
    private CommandLetter commL;
    /**
     * Default constructor for test class CommandLetterTest
     */
    public CommandLetterTest()
    {
        commL = new CommandLetter();
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
    
    /**
     * Method test getValid method. This method return a boolean which saying if the command is valid
     *
     */
    @Test
    public void testGetValid()
    {
        assertEquals(false,commL.getValid()); 
    }
    
}
