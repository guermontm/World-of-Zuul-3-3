import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class QuestTest.
 *
 * @author  Group5
 * @version 23/11/2017
 */
public class QuestTest
{
    private Quest quest;
    /**
     * Default constructor for test class QuestTest
     */
    public QuestTest()
    {
        
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
        quest = new Quest();
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
    
    /**
     * Test of the getQuestEnded method
     */
    @Test
    public void testGetQuestEnded(){
        assertEquals(false, quest.getQuestEnded(0));
    }
    /**
     * Test of the questFindingSubject method
     */
    @Test
    public void testQuestFindingSubject(){
        quest.questFindingSubject();
        assertEquals("currently running", quest.getQuestTable(1,2));
        assertEquals("currently running", quest.getQuestTable(2,2));
        assertEquals("currently running", quest.getQuestTable(3,2));
        assertEquals("finished", quest.getQuestTable(0,2));
    }
    /**
     * Test of the questGatheringGroup method
     */
    @Test
    public void testQuestGatheringGroup(){
        quest.questGatheringGroup();
        assertEquals("currently running", quest.getQuestTable(6,2));
        assertEquals("finished", quest.getQuestTable(1,2));
    }
    /**
     * Test of the questDiploma method
     */
    @Test
    public void testQuestDiploma(){
        quest.questDiploma();
        assertEquals("finished", quest.getQuestTable(2,2));
        assertEquals("currently running", quest.getQuestTable(4,2));
    }
    /**
     * Test of the questDiploma2 method
     */
    @Test
    public void testQuestDiploma2(){
        quest.questDiploma();
        assertEquals("finished", quest.getQuestTable(4,2));
    }
    
    /**
     *Test of the questToilets method
     */
    @Test
    public void testQuestToilets(){
     quest.questToilets();
     assertEquals("currently running", quest.getQuestTable(5,2));   
     assertEquals("finished", quest.getQuestTable(3,2));
    }
    /**
     * Test of the questToilets2 method
     */
    @Test
    public void testToilets2(){
        quest.questToilets2();
        assertEquals("finished", quest.getQuestTable(5,2));
    }
    
    /**
     * Test of the questCode method
     */
    @Test
    public void testCode(){
     quest.questCode();
     assertEquals("currently running", quest.getQuestTable(7,2));  
     assertEquals("finished", quest.getQuestTable(6,2));
    }
    
    /**
     * Test of the questFinish method
     */
    @Test
    public void testFinish(){
     quest.questFinish();
     assertEquals("finished", quest.getQuestTable(7,2));   
    }
}

