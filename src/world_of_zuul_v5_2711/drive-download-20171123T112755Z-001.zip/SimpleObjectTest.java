import java.awt.*;
import java.io.*;
import java.util.*;

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class SimpleObjectTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class SimpleObjectTest
{
    private SimpleObject object;
    /**
     * Default constructor for test class SimpleObjectTest
     */
    public SimpleObjectTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
        object = new SimpleObject("key",true);
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

    /**
     * Method testInteractItem test the System.out.println in the interactItem method. 
     *
     */
    @Test
    public void testInteractItem() throws Exception 
    {
        PrintStream save_out=System.out;
        final ByteArrayOutputStream out = new ByteArrayOutputStream();
        System.setOut(new PrintStream(out));

        object.interactItem();

        //String expectedOutput  = "Hello";
        assertEquals("You have found a key !\r\n", out.toString());
    } 
    
    /**
     * Method testGetName test if the name is not empty 
     *
     */
    @Test
    public void testGetName()
    {
        if(object.getName()=="")
        {
            fail("The name cannot be null");
        }
        else 
        {
         assertEquals("key", object.getName());   
        }
    }
    
    /**
     * Method testGetLock test if the boolean lock is the same as the initialization 
     *
     */
    @Test
    public void testGetLock()
    {
        assertEquals(true, object.getLock());
    }
    
    
    /**
     * Method testSetLock test the method which change isLock 
     *
     */
    @Test
    public void testSetLock()
    {
        object.setLock();
        assertEquals(false, object.getLock());
    }
}
